#!/bin/sh
sh /koolshare/scripts/config-frpc.sh